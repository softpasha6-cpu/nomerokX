# NomerX — Telegram Mini App starter

Russian-language starter for a vehicle-number collecting game. Includes a FastAPI API, Telegram bot, dark mobile UI, SQLite schema, individual catalog item prices, containers with server-side weighted drops, garage, player-to-player marketplace, transaction history, admin endpoints and audit log.

## Current scope / important limitations
This is a functional starter, not a finished production clone. It intentionally does not copy private source code or assets from Nomerok. The UI is original but inspired by the supplied screenshots.
- Container opening, inventory, listings and marketplace purchase are implemented server-side.
- Item prices are individually configurable from admin endpoints.
- Admin access is based on numeric Telegram IDs in `ADMIN_IDS`.
- Telegram `initData` is HMAC-validated when `DEMO_MODE=false`.
- The web UI has admin overview, item/container price editing, user balance/ban controls and audit view.
- Telegram Stars integration is not yet wired: a production implementation should add `sendInvoice`/`createInvoiceLink`, validate `successful_payment`, persist `telegram_payment_charge_id`, and make crediting idempotent. Do not credit Stars or in-game value from a client-side callback.
- Catalog item direct purchase is not implemented in the UI yet; items can be obtained from containers and marketplace. Add a server-side purchase endpoint if direct catalog purchases are required.
- Configure persistent storage for SQLite on cloud hosting, or migrate to PostgreSQL before horizontal scaling.
- Configure TLS/HTTPS and a public APP_URL. Telegram Mini Apps require HTTPS.
- Add rate limiting, CSRF/origin policy where relevant, monitoring, backups, and integration tests before launch.

## Local development
1. Install Python 3.12+.
2. `python -m venv .venv` then activate it.
3. `pip install -r requirements.txt`
4. Copy `.env.example` to `.env`, set `BOT_TOKEN`, `APP_URL`, `ADMIN_IDS`.
5. For local browser-only testing only, set `DEMO_MODE=true`.
6. Run API: `uvicorn app:app --reload --port 8000`.
7. In another terminal run bot: `python bot.py`.
8. Open `http://127.0.0.1:8000` for demo. Telegram's actual WebApp button requires public HTTPS.

## Cloud deployment
1. Create a cloud service supporting Docker and persistent disks (Render, Railway, Fly.io, or a VPS with Docker).
2. Set secrets as environment variables; never commit `.env`.
3. Set `BOT_TOKEN` from BotFather; `APP_URL` to the deployed HTTPS URL; `ADMIN_IDS` to comma-separated numeric Telegram user IDs; `DEMO_MODE=false`.
4. Attach persistent storage and set `DATABASE_PATH` to a path on that storage. Back up the DB.
5. Deploy web service, verify `/api/health`, then run `python bot.py` as a separate always-on worker.
6. In BotFather configure the Mini App/menu button to the HTTPS URL if desired.
7. Test login with a non-admin account, admin denial, container purchase with insufficient balance, concurrent marketplace purchase, ban handling and backups.

## Admin API
- `GET /api/admin/overview`
- `GET /api/admin/items`
- `PATCH /api/admin/items/{item_id}/price` body `{"price":123}`
- `GET /api/admin/users`
- `PATCH /api/admin/users/{user_id}` body `{"balance":123,"banned":false}`
- `GET /api/admin/containers`
- `PATCH /api/admin/containers/{container_id}/price` body `{"price":123}`

Admin API uses the same verified Telegram initData as the game. Never deploy with `DEMO_MODE=true`.

## Economy design
All prices and balances are integer units of in-game currency. Marketplace takes a 5% fee. Container drops use server-side weights. In production, version drop tables and log each drop seed/result for auditability; do not rely on UI probabilities.
