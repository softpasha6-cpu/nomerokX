import os, json, random, sqlite3, time, hmac, hashlib
from contextlib import contextmanager
from urllib.parse import parse_qsl
from fastapi import FastAPI, HTTPException, Request, Header
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from dotenv import load_dotenv

load_dotenv()
DB = os.getenv("DATABASE_PATH", "nomerx.db")
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
ADMIN_IDS = {int(x) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()}
app = FastAPI(title="NomerX API", version="1.0.0")
app.mount("/static", StaticFiles(directory="static"), name="static")

@contextmanager
def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    try:
        yield con
        con.commit()
    finally:
        con.close()

def init_db():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users(
          id INTEGER PRIMARY KEY, username TEXT, balance INTEGER NOT NULL DEFAULT 100000,
          stars INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, banned INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS items(
          id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, title TEXT NOT NULL,
          rarity TEXT NOT NULL DEFAULT 'Обычный', price INTEGER NOT NULL CHECK(price>=0),
          region TEXT DEFAULT 'Россия', metadata TEXT DEFAULT '{}', active INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS inventory(
          id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, item_id INTEGER NOT NULL,
          serial TEXT, acquired_at INTEGER NOT NULL, UNIQUE(id));
        CREATE TABLE IF NOT EXISTS containers(
          id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, price INTEGER NOT NULL CHECK(price>=0),
          active INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS container_drops(
          container_id INTEGER NOT NULL, item_id INTEGER NOT NULL, weight REAL NOT NULL CHECK(weight>=0),
          PRIMARY KEY(container_id,item_id));
        CREATE TABLE IF NOT EXISTS listings(
          id INTEGER PRIMARY KEY AUTOINCREMENT, inventory_id INTEGER NOT NULL UNIQUE,
          seller_id INTEGER NOT NULL, price INTEGER NOT NULL CHECK(price>0),
          status TEXT NOT NULL DEFAULT 'active', created_at INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS transactions(
          id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, kind TEXT NOT NULL,
          amount INTEGER NOT NULL, balance_after INTEGER NOT NULL, details TEXT, created_at INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS audit(
          id INTEGER PRIMARY KEY AUTOINCREMENT, actor_id INTEGER, action TEXT NOT NULL,
          target TEXT, details TEXT, created_at INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS payments(
          id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, telegram_charge_id TEXT UNIQUE,
          stars INTEGER NOT NULL, payload TEXT NOT NULL, created_at INTEGER NOT NULL);
        """)
        if c.execute("SELECT COUNT(*) FROM items").fetchone()[0] == 0:
            seeds = [
              ("plate","C216EC · 75","Необычный",1645,"Забайкальский край",{"pattern":"C216EC","region_code":"75"}),
              ("plate","A777AA · 77","Легендарный",1250000,"Москва",{"pattern":"A777AA","region_code":"77"}),
              ("plate","E888BA · 88","Секретный",156250000,"Россия",{"pattern":"E888BA","region_code":"88"}),
              ("car","Lada Granta","Обычный",85000,"Россия",{"power":87}),
              ("car","BMW M5","Эпический",2800000,"Германия",{"power":625}),
              ("car","Porsche 911","Легендарный",12500000,"Германия",{"power":650}),
              ("car","Bugatti Chiron","Мифический",85000000,"Франция",{"power":1500}),
            ]
            c.executemany("INSERT INTO items(kind,title,rarity,price,region,metadata) VALUES(?,?,?,?,?,?)",
                          [(k,t,r,p,reg,json.dumps(m,ensure_ascii=False)) for k,t,r,p,reg,m in seeds])
            c.executemany("INSERT INTO containers(title,price) VALUES(?,?)",
                          [("Обычный контейнер",10000),("Редкий контейнер",30000),("Эпический контейнер",100000),("Легендарный контейнер",300000)])
            for box in c.execute("SELECT id FROM containers").fetchall():
                c.executemany("INSERT INTO container_drops(container_id,item_id,weight) VALUES(?,?,?)",
                              [(box["id"], item["id"], w) for item,w in zip(c.execute("SELECT id FROM items").fetchall(),[50,20,3,35,10,4,1])])
init_db()

def verify_init_data(init_data: str):
    if not BOT_TOKEN:
        return None
    pairs = dict(parse_qsl(init_data, keep_blank_values=True))
    received = pairs.pop("hash", None)
    if not received:
        return None
    check = "\n".join(f"{k}={v}" for k,v in sorted(pairs.items()))
    secret = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
    expected = hmac.new(secret, check.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, received):
        return None
    try:
        auth_date = int(pairs.get("auth_date", "0"))
        if abs(time.time()-auth_date) > 86400: return None
        user = json.loads(pairs["user"])
        return user
    except Exception:
        return None

async def current_user(request: Request, x_telegram_init_data: str = Header(default="")):
    # Local demo mode is deliberately restricted to development.
    if os.getenv("DEMO_MODE","false").lower() == "true":
        uid = int(request.headers.get("x-demo-user-id","10001"))
        user = {"id":uid,"username":"demo"}
    else:
        user = verify_init_data(x_telegram_init_data)
        if not user: raise HTTPException(401,"Telegram initData не прошёл проверку")
        uid = int(user["id"])
    with db() as c:
        c.execute("INSERT OR IGNORE INTO users(id,username,created_at) VALUES(?,?,?)",
                  (uid,user.get("username",""),int(time.time())))
        row = c.execute("SELECT * FROM users WHERE id=?",(uid,)).fetchone()
        if row["banned"]: raise HTTPException(403,"Аккаунт ограничен")
    return dict(row)

def audit(actor, action, target="", details=""):
    with db() as c:
        c.execute("INSERT INTO audit(actor_id,action,target,details,created_at) VALUES(?,?,?,?,?)",
                  (actor,action,str(target),str(details)[:2000],int(time.time())))

class PriceUpdate(BaseModel):
    price: int = Field(ge=0, le=10**12)
class AdminUserUpdate(BaseModel):
    balance: int = Field(ge=0, le=10**15)
    banned: bool = False
class ListingCreate(BaseModel):
    inventory_id: int
    price: int = Field(gt=0, le=10**12)
class OpenContainer(BaseModel):
    container_id: int

@app.get("/")
def index():
    return FileResponse("static/index.html")

@app.get("/api/me")
async def me(request: Request, x_telegram_init_data: str = Header(default="")):
    u = await current_user(request,x_telegram_init_data)
    return {"id":u["id"],"username":u["username"],"balance":u["balance"],"stars":u["stars"]}

@app.get("/api/catalog")
async def catalog(request: Request, x_telegram_init_data: str = Header(default="")):
    await current_user(request,x_telegram_init_data)
    with db() as c:
        items=[dict(r) for r in c.execute("SELECT * FROM items WHERE active=1 ORDER BY price")]
        boxes=[dict(r) for r in c.execute("SELECT * FROM containers WHERE active=1 ORDER BY price")]
    for i in items: i["metadata"]=json.loads(i["metadata"])
    return {"items":items,"containers":boxes}

@app.get("/api/garage")
async def garage(request: Request, x_telegram_init_data: str = Header(default="")):
    u=await current_user(request,x_telegram_init_data)
    with db() as c:
        rows=c.execute("""SELECT inventory.id AS inventory_id, inventory.serial, inventory.acquired_at,
        items.* FROM inventory JOIN items ON items.id=inventory.item_id
        WHERE inventory.user_id=? ORDER BY inventory.id DESC""",(u["id"],)).fetchall()
    return [dict(r) for r in rows]

@app.post("/api/container/open")
async def open_container(body: OpenContainer, request: Request, x_telegram_init_data: str = Header(default="")):
    u=await current_user(request,x_telegram_init_data)
    now=int(time.time())
    with db() as c:
        c.execute("BEGIN IMMEDIATE")
        box=c.execute("SELECT * FROM containers WHERE id=? AND active=1",(body.container_id,)).fetchone()
        if not box: raise HTTPException(404,"Контейнер не найден")
        if u["balance"] < box["price"]: raise HTTPException(400,"Недостаточно игровой валюты")
        drops=c.execute("""SELECT i.id,i.title,i.kind,i.price,i.rarity,d.weight FROM container_drops d
          JOIN items i ON i.id=d.item_id WHERE d.container_id=? AND i.active=1 AND d.weight>0""",(box["id"],)).fetchall()
        if not drops: raise HTTPException(400,"В контейнере нет предметов")
        chosen=random.choices(drops,weights=[r["weight"] for r in drops],k=1)[0]
        balance=u["balance"]-box["price"]
        c.execute("UPDATE users SET balance=? WHERE id=?",(balance,u["id"]))
        cur=c.execute("INSERT INTO inventory(user_id,item_id,serial,acquired_at) VALUES(?,?,?,?)",
                      (u["id"],chosen["id"],None,now))
        c.execute("INSERT INTO transactions(user_id,kind,amount,balance_after,details,created_at) VALUES(?,?,?,?,?,?)",
                  (u["id"],"container_open",-box["price"],balance,json.dumps({"container":box["title"],"drop":chosen["title"]},ensure_ascii=False),now))
    return {"item":dict(chosen),"balance":balance,"inventory_id":cur.lastrowid}

@app.post("/api/market/list")
async def market_list(body: ListingCreate, request: Request, x_telegram_init_data: str = Header(default="")):
    u=await current_user(request,x_telegram_init_data)
    with db() as c:
        inv=c.execute("SELECT * FROM inventory WHERE id=? AND user_id=?",(body.inventory_id,u["id"])).fetchone()
        if not inv: raise HTTPException(404,"Предмет не найден в гараже")
        c.execute("INSERT INTO listings(inventory_id,seller_id,price,created_at) VALUES(?,?,?,?)",
                  (inv["id"],u["id"],body.price,int(time.time())))
        audit(u["id"],"market_list",body.inventory_id,body.price)
    return {"ok":True}

@app.get("/api/market")
async def market(request: Request, x_telegram_init_data: str = Header(default="")):
    await current_user(request,x_telegram_init_data)
    with db() as c:
        return [dict(r) for r in c.execute("""SELECT l.id,l.price,l.seller_id,i.id item_id,i.title,i.kind,i.rarity,i.region
        FROM listings l JOIN inventory v ON v.id=l.inventory_id JOIN items i ON i.id=v.item_id
        WHERE l.status='active' ORDER BY l.price DESC LIMIT 100""")]

@app.post("/api/market/{listing_id}/buy")
async def market_buy(listing_id:int, request:Request, x_telegram_init_data:str=Header(default="")):
    u=await current_user(request,x_telegram_init_data); now=int(time.time())
    with db() as c:
        c.execute("BEGIN IMMEDIATE")
        l=c.execute("SELECT * FROM listings WHERE id=? AND status='active'",(listing_id,)).fetchone()
        if not l: raise HTTPException(404,"Лот уже недоступен")
        if l["seller_id"]==u["id"]: raise HTTPException(400,"Нельзя купить собственный лот")
        buyer=c.execute("SELECT balance FROM users WHERE id=?",(u["id"],)).fetchone()
        if buyer["balance"]<l["price"]: raise HTTPException(400,"Недостаточно игровой валюты")
        fee=l["price"]//20; seller_net=l["price"]-fee
        c.execute("UPDATE users SET balance=balance-? WHERE id=?",(l["price"],u["id"]))
        c.execute("UPDATE users SET balance=balance+? WHERE id=?",(seller_net,l["seller_id"]))
        c.execute("UPDATE inventory SET user_id=? WHERE id=?",(u["id"],l["inventory_id"]))
        c.execute("UPDATE listings SET status='sold' WHERE id=?",(listing_id,))
        for uid,kind,amount in [(u["id"],"market_buy",-l["price"]),(l["seller_id"],"market_sale",seller_net)]:
            bal=c.execute("SELECT balance FROM users WHERE id=?",(uid,)).fetchone()["balance"]
            c.execute("INSERT INTO transactions(user_id,kind,amount,balance_after,details,created_at) VALUES(?,?,?,?,?,?)",
                      (uid,kind,amount,bal,json.dumps({"listing_id":listing_id},ensure_ascii=False),now))
    return {"ok":True}

@app.get("/api/transactions")
async def transactions(request:Request,x_telegram_init_data:str=Header(default="")):
    u=await current_user(request,x_telegram_init_data)
    with db() as c:
        return [dict(r) for r in c.execute("SELECT * FROM transactions WHERE user_id=? ORDER BY id DESC LIMIT 100",(u["id"],))]

@app.get("/api/admin/overview")
async def admin_overview(request:Request,x_telegram_init_data:str=Header(default="")):
    u=await current_user(request,x_telegram_init_data)
    if u["id"] not in ADMIN_IDS: raise HTTPException(403,"Только для администратора")
    with db() as c:
        return {"users":c.execute("SELECT COUNT(*) FROM users").fetchone()[0],
                "items":c.execute("SELECT COUNT(*) FROM items").fetchone()[0],
                "listings":c.execute("SELECT COUNT(*) FROM listings WHERE status='active'").fetchone()[0],
                "transactions":c.execute("SELECT COUNT(*) FROM transactions").fetchone()[0],
                "audit":[dict(r) for r in c.execute("SELECT * FROM audit ORDER BY id DESC LIMIT 50")]}

@app.get("/api/admin/items")
async def admin_items(request:Request,x_telegram_init_data:str=Header(default="")):
    u=await current_user(request,x_telegram_init_data)
    if u["id"] not in ADMIN_IDS: raise HTTPException(403,"Только для администратора")
    with db() as c: return [dict(r) for r in c.execute("SELECT * FROM items ORDER BY id DESC")]

@app.patch("/api/admin/items/{item_id}/price")
async def admin_price(item_id:int, body:PriceUpdate, request:Request,x_telegram_init_data:str=Header(default="")):
    u=await current_user(request,x_telegram_init_data)
    if u["id"] not in ADMIN_IDS: raise HTTPException(403,"Только для администратора")
    with db() as c:
        if not c.execute("SELECT id FROM items WHERE id=?",(item_id,)).fetchone(): raise HTTPException(404,"Предмет не найден")
        c.execute("UPDATE items SET price=? WHERE id=?",(body.price,item_id))
    audit(u["id"],"price_update",item_id,body.price)
    return {"ok":True}

@app.get("/api/admin/users")
async def admin_users(request:Request,x_telegram_init_data:str=Header(default="")):
    u=await current_user(request,x_telegram_init_data)
    if u["id"] not in ADMIN_IDS: raise HTTPException(403,"Только для администратора")
    with db() as c: return [dict(r) for r in c.execute("SELECT id,username,balance,stars,created_at,banned FROM users ORDER BY created_at DESC LIMIT 500")]

@app.patch("/api/admin/users/{user_id}")
async def admin_user_update(user_id:int, body:AdminUserUpdate, request:Request,x_telegram_init_data:str=Header(default="")):
    u=await current_user(request,x_telegram_init_data)
    if u["id"] not in ADMIN_IDS: raise HTTPException(403,"Только для администратора")
    with db() as c:
        c.execute("UPDATE users SET balance=?,banned=? WHERE id=?",(body.balance,int(body.banned),user_id))
        if c.total_changes==0: raise HTTPException(404,"Пользователь не найден")
    audit(u["id"],"user_update",user_id,body.model_dump())
    return {"ok":True}

@app.get("/api/admin/containers")
async def admin_containers(request:Request,x_telegram_init_data:str=Header(default="")):
    u=await current_user(request,x_telegram_init_data)
    if u["id"] not in ADMIN_IDS: raise HTTPException(403,"Только для администратора")
    with db() as c: return [dict(r) for r in c.execute("SELECT * FROM containers ORDER BY id")]

@app.patch("/api/admin/containers/{container_id}/price")
async def admin_container_price(container_id:int,body:PriceUpdate,request:Request,x_telegram_init_data:str=Header(default="")):
    u=await current_user(request,x_telegram_init_data)
    if u["id"] not in ADMIN_IDS: raise HTTPException(403,"Только для администратора")
    with db() as c: c.execute("UPDATE containers SET price=? WHERE id=?",(body.price,container_id))
    audit(u["id"],"container_price_update",container_id,body.price)
    return {"ok":True}

@app.get("/api/health")
def health(): return {"ok":True,"service":"NomerX"}
