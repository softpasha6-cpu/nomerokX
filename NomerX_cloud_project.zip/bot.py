import os, asyncio
from aiogram import Bot, Dispatcher, F
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
from aiogram.filters import CommandStart
from dotenv import load_dotenv
load_dotenv()
TOKEN=os.getenv("BOT_TOKEN","")
APP_URL=os.getenv("APP_URL","")
dp=Dispatcher()
@dp.message(CommandStart())
async def start(m:Message):
    if not APP_URL.startswith("https://"):
        await m.answer("NomerX: сначала укажи публичный HTTPS APP_URL в настройках.")
        return
    kb=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="🚘 Открыть NomerX",web_app=WebAppInfo(url=APP_URL))]])
    await m.answer("Добро пожаловать в NomerX!\nНомера, гараж, контейнеры и внутриигровой рынок.",reply_markup=kb)
async def main():
    if not TOKEN: raise RuntimeError("Укажи BOT_TOKEN")
    bot=Bot(TOKEN)
    await dp.start_polling(bot)
if __name__=="__main__": asyncio.run(main())
